# Mikita Volume Bar

Projet Android Java prévu pour Android 6.0+ et importable dans Android Studio / CodeAssist.

## Fonctions
- Interception des touches Volume + et Volume - via un service d'accessibilité.
- Réglage du volume multimédia Android.
- Barre personnalisable : forme, position, longueur, épaisseur, arrondi, couleurs, animations, durée, délai et décalages.
- Aperçu depuis l'application lorsque le service est actif.

## Installation
1. Ouvre le dossier `MikitaVolumeBar` dans CodeAssist comme projet Gradle.
2. Laisse Gradle synchroniser le projet (Android Gradle Plugin 8.6.1, Gradle 8.7 recommandé, JDK 17).
3. Compile et installe l'APK.
4. Ouvre l'application puis touche **Activer l'accessibilité**.
5. Dans les paramètres Android, active **Mikita Volume Bar** et accepte l'avertissement système.
6. Reviens dans l'application et teste les boutons physiques de volume.

## Démarrage automatique
Android gère lui-même le cycle de vie des services d'accessibilité activés et les reconnecte normalement après redémarrage. L'application ne peut pas activer cette autorisation à la place de l'utilisateur. Certains systèmes (dont MIUI) peuvent imposer des restrictions supplémentaires d'arrière-plan : autorise le démarrage automatique / l'exécution en arrière-plan pour l'application si le réglage existe.

## Limites
- La barre remplace l'affichage visuel lors de l'utilisation des touches de volume, mais l'interface système peut encore apparaître brièvement selon la version Android / MIUI.
- Le volume contrôlé ici est le volume multimédia.
- Les options de personnalisation sont enregistrées localement dans les préférences de l'application.
