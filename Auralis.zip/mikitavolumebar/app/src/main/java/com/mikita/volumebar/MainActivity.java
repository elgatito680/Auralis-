
package com.mikita.volumebar;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import android.content.pm.PackageManager;

public class MainActivity extends Activity {

    private SharedPreferences prefs;
    private LinearLayout root;
    private PreviewView preview;
    private TextView serviceStatus;
    private TextView autostartStatus;
    private TextView batteryStatus;

    private final int BG = 0xFF080808;
    private final int CARD = 0xFF171717;
    private final int WHITE = Color.WHITE;
    private final int GREY = 0xFF999999;

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("style", MODE_PRIVATE);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        build();
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);

        root = new LinearLayout(this);
        root.setOrientation(1);
        root.setPadding(dp(20), dp(28), dp(20), dp(35));
        scroll.addView(root);
        setContentView(scroll);

        TextView brand = text("MIKITA", 13, true);
        brand.setTextColor(GREY);
        root.addView(brand);

        root.addView(text("Volume Bar", 30, true));

        TextView subtitle = text("Personnalise ton indicateur", 13, false);
        subtitle.setTextColor(GREY);
        root.addView(subtitle);

        section("APERÇU");
        LinearLayout previewCard = card();

        preview = new PreviewView(this);
        previewCard.addView(preview,
            new LinearLayout.LayoutParams(-1, dp(190)));

        section("SERVICE");
        LinearLayout serviceCard = card();

        serviceStatus = text("Vérification...", 14, true);
        serviceCard.addView(serviceStatus);

        Button access = button("OUVRIR L'ACCESSIBILITÉ");
        serviceCard.addView(access);

        access.setOnClickListener(v ->
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        );

        Button test = button("TESTER LA BARRE");
        serviceCard.addView(test);

        test.setOnClickListener(v ->
            VolumeAccessibilityService.preview(this)
        );

        // FONCTIONNEMENT EN ARRIÈRE-PLAN

        section("FONCTIONNEMENT EN ARRIÈRE-PLAN");

        LinearLayout backgroundCard = card();

        TextView backgroundInfo = text(
            "Configure ces autorisations pour permettre à Mikita Volume Bar " +
            "de fonctionner correctement lorsque l'application est en arrière-plan.",
            13, false
        );
        backgroundInfo.setTextColor(GREY);
        backgroundCard.addView(backgroundInfo);

        autostartStatus = text("Vérification...", 13, true);
        autostartStatus.setPadding(0, dp(15), 0, dp(5));
        backgroundCard.addView(autostartStatus);

        Button autostartButton = button("ACTIVER LE DÉMARRAGE AUTOMATIQUE");
        backgroundCard.addView(autostartButton);

        autostartButton.setOnClickListener(v -> openAutostartSettings());

        batteryStatus = text("Vérification...", 13, true);
        batteryStatus.setPadding(0, dp(18), 0, dp(5));
        backgroundCard.addView(batteryStatus);

        Button batteryButton = button("AUTORISER LA BATTERIE SANS RESTRICTION");
        backgroundCard.addView(batteryButton);

        batteryButton.setOnClickListener(v -> openBatterySettings());

        TextView warning = text(
            "Ces autorisations doivent être confirmées manuellement " +
            "dans les paramètres Android ou Xiaomi.",
            11, false
        );
        warning.setTextColor(GREY);
        warning.setPadding(0, dp(15), 0, 0);
        backgroundCard.addView(warning);

        section("POSITION");

        addSpinner("Position de la barre", "position",
            new String[]{"À gauche", "À droite", "Au centre"},
            new String[]{"left", "right", "center"});

        addSeek("Marge", "margin", 0, 100, 28);
        addSeek("Décalage horizontal", "offsetX", -100, 100, 0);
        addSeek("Décalage vertical", "offsetY", -200, 200, 0);

        section("FOND");

        addSpinner("Forme du fond", "shape",
            new String[]{"Pilule", "Arrondie", "Carrée", "Encoche"},
            new String[]{"pill", "round", "square", "notch"});

        addSeek("Largeur du fond", "backgroundPadding", 0, 35, 10);
        addSeek("Arrondi du fond", "radius", 0, 40, 18);

        section("ANIMATION D'ENTRÉE");

        addSpinner("Style d'entrée", "animation",
            new String[]{"Fondu", "Glissement", "Fondu + glissement", "Aucune"},
            new String[]{"fade", "slide", "both", "none"});

        addSeek("Durée d'entrée", "duration", 0, 1000, 180);

        section("ANIMATION DE SORTIE");

        addSpinner("Style de sortie", "exitAnimation",
            new String[]{"Fondu", "Glissement", "Fondu + glissement", "Aucune"},
            new String[]{"fade", "slide", "both", "none"});

        addSeek("Durée de sortie", "exitDuration", 0, 1000, 180);

        addSeek("Délai avant disparition", "hideDelay", 300, 5000, 1600);

        section("ANIMATION DU VOLUME");

        addSpinner("Style de progression", "progressAnimation",
            new String[]{"Fluide", "Ressort", "Linéaire", "Instantané"},
            new String[]{"smooth", "spring", "linear", "none"});

        addSeek("Durée de progression", "progressDuration", 50, 700, 220);

        section("DIMENSIONS");

        addSeek("Hauteur", "length", 100, 500, 230);
        addSeek("Épaisseur de la piste", "thickness", 2, 25, 8);

        section("COULEURS");

        addColorChoice("Fond", "background", new int[]{
            Color.BLACK, 0xFF111111, 0xFF222222, 0xFF333333
        });

        addColorChoice("Piste", "track", new int[]{
            0xFF777777, 0xFFAAAAAA, 0xFF444444, 0xFFCCCCCC
        });

        addColorChoice("Progression", "fill", new int[]{
            Color.WHITE, 0xFFBDBDBD, 0xFF80CBC4, 0xFF90CAF9
        });

        section("UTILISATION");

        TextView info = text(
            "Maintiens Volume + pour augmenter le volume. " +
            "Maintiens Volume - pour le diminuer. " +
            "Le volume s'arrête dès le relâchement.",
            13, false
        );
        info.setTextColor(GREY);
        root.addView(info);
    }

    // DÉMARRAGE AUTOMATIQUE XIAOMI

    private void openAutostartSettings() {
        try {
            Intent intent = new Intent();
            intent.setComponent(new ComponentName(
                "com.miui.securitycenter",
                "com.miui.permcenter.autostart.AutoStartManagementActivity"
            ));
            startActivity(intent);

        } catch (Exception e) {
            openAppSettings();
        }
    }

    // BATTERIE SANS RESTRICTION

    private void openBatterySettings() {
        try {
            Intent intent = new Intent(
                Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS
            );

            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);

        } catch (Exception e) {
            openAppSettings();
        }
    }

    // PARAMÈTRES DE L'APPLICATION

    private void openAppSettings() {
        try {
            Intent intent = new Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS
            );

            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);

        } catch (Exception e) {
            Toast.makeText(
                this,
                "Impossible d'ouvrir les paramètres.",
                Toast.LENGTH_SHORT
            ).show();
        }
    }

    // VÉRIFICATION DES AUTORISATIONS

    private boolean isBatteryUnrestricted() {
        android.os.PowerManager pm =
            (android.os.PowerManager) getSystemService(POWER_SERVICE);

        return pm != null &&
            pm.isIgnoringBatteryOptimizations(getPackageName());
    }

    private void updateBackgroundStatus() {

        if (autostartStatus != null) {
            autostartStatus.setText(
                "Démarrage automatique : à vérifier"
            );
            autostartStatus.setTextColor(0xFFFFB74D);
        }

        if (batteryStatus != null) {

            boolean unrestricted = isBatteryUnrestricted();

            batteryStatus.setText(
                unrestricted
                    ? "● Batterie sans restriction"
                    : "○ Optimisation de batterie active"
            );

            batteryStatus.setTextColor(
                unrestricted ? 0xFF8BC34A : 0xFFFFB74D
            );
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
        updatePreview();
        updateBackgroundStatus();
    }

    private void updateStatus() {
        if (serviceStatus == null) return;

        boolean enabled = VolumeAccessibilityService.isEnabled(this);

        serviceStatus.setText(enabled
            ? "● Service activé"
            : "○ Service désactivé");

        serviceStatus.setTextColor(enabled
            ? 0xFF8BC34A
            : 0xFFFFB74D);
    }

    private void updatePreview() {
        if (preview != null) preview.invalidate();
    }

    private void section(String name) {
        TextView t = text(name, 12, true);
        t.setTextColor(0xFF888888);
        t.setPadding(dp(3), dp(24), 0, dp(12));
        root.addView(t);
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(1);
        box.setPadding(dp(15), dp(15), dp(15), dp(15));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(CARD);
        bg.setCornerRadius(dp(17));
        box.setBackground(bg);

        LinearLayout.LayoutParams p =
            new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(12);
        root.addView(box, p);
        return box;
    }

    private void addSpinner(
        String label, String key, String[] labels, String[] values
    ) {
        LinearLayout box = card();
        box.addView(text(label, 14, true));

        Spinner spinner = new Spinner(this);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
            this, android.R.layout.simple_spinner_item, labels
        );

        adapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        );

        spinner.setAdapter(adapter);

        String current = prefs.getString(key, values[0]);

        for (int i = 0; i < values.length; i++) {
            if (values[i].equals(current)) {
                spinner.setSelection(i);
                break;
            }
        }

        box.addView(spinner, new LinearLayout.LayoutParams(-1, dp(45)));

        spinner.setOnItemSelectedListener(
            new android.widget.AdapterView.OnItemSelectedListener() {
                public void onNothingSelected(
                    android.widget.AdapterView<?> parent
                ) {}

                public void onItemSelected(
                    android.widget.AdapterView<?> parent,
                    View view, int position, long id
                ) {
                    prefs.edit().putString(key, values[position]).apply();
                    updatePreview();
                    VolumeAccessibilityService.refresh();
                }
            }
        );
    }

    private void addSeek(
        String label, String key, int min, int max, int def
    ) {
        LinearLayout box = card();

        TextView value = text(
            label + " · " + prefs.getInt(key, def), 14, true
        );
        box.addView(value);

        SeekBar seek = new SeekBar(this);
        seek.setMax(max - min);
        seek.setProgress(prefs.getInt(key, def) - min);
        box.addView(seek);

        seek.setOnSeekBarChangeListener(
            new SeekBar.OnSeekBarChangeListener() {
                public void onProgressChanged(
                    SeekBar bar, int progress, boolean user
                ) {
                    int v = progress + min;
                    value.setText(label + " · " + v);

                    if (user) {
                        prefs.edit().putInt(key, v).apply();
                        updatePreview();
                        VolumeAccessibilityService.refresh();
                    }
                }

                public void onStartTrackingTouch(SeekBar bar) {}
                public void onStopTrackingTouch(SeekBar bar) {}
            }
        );
    }

    private void addColorChoice(
        String label, String key, int[] colors
    ) {
        LinearLayout box = card();
        box.addView(text(label, 14, true));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);

        for (int color : colors) {
            View swatch = new View(this);

            GradientDrawable shape = new GradientDrawable();
            shape.setColor(color);
            shape.setCornerRadius(dp(10));
            shape.setStroke(dp(1), 0xFF666666);
            swatch.setBackground(shape);

            LinearLayout.LayoutParams p =
                new LinearLayout.LayoutParams(dp(40), dp(38));
            p.setMargins(0, dp(12), dp(12), 0);
            row.addView(swatch, p);

            swatch.setOnClickListener(v -> {
                prefs.edit().putInt(key, color).apply();
                updatePreview();
                VolumeAccessibilityService.refresh();
            });
        }

        box.addView(row);
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(12);
        b.setTextColor(Color.BLACK);
        b.setBackgroundTintList(
            android.content.res.ColorStateList.valueOf(WHITE)
        );

        LinearLayout.LayoutParams p =
            new LinearLayout.LayoutParams(-1, dp(48));
        p.topMargin = dp(9);
        b.setLayoutParams(p);
        return b;
    }

    private TextView text(String value, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(WHITE);
        t.setTextSize(size);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }

    private int dp(float value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private class PreviewView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        PreviewView(Context c) {
            super(c);
        }

        private Path makePath(RectF rect, String shape, boolean left, float radius) {
            Path path = new Path();

            if ("square".equals(shape)) {
                path.addRect(rect, Path.Direction.CW);
            } else if ("notch".equals(shape)) {
                float[] radii = left
                    ? new float[]{0,0,radius,radius,radius,radius,0,0}
                    : new float[]{radius,radius,0,0,0,0,radius,radius};
                path.addRoundRect(rect, radii, Path.Direction.CW);
            } else {
                float r = "round".equals(shape)
                    ? Math.min(radius, rect.width()/2f)
                    : rect.width()/2f;
                path.addRoundRect(rect, r, r, Path.Direction.CW);
            }
            return path;
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            float d = getResources().getDisplayMetrics().density;

            String shape = prefs.getString("shape", "pill");
            String position = prefs.getString("position", "right");

            float height = Math.min(prefs.getInt("length", 230)*d, getHeight()-dp(20));
            float width = prefs.getInt("thickness", 8)*d;
            float pad = prefs.getInt("backgroundPadding", 10)*d;
            float radius = prefs.getInt("radius", 18)*d;

            float cx = "left".equals(position) ? dp(35) :
                "center".equals(position) ? getWidth()/2f : getWidth()-dp(35);

            cx += prefs.getInt("offsetX", 0)*d;
            float cy = getHeight()/2f + prefs.getInt("offsetY", 0)*d;

            float tl = cx-width/2f;
            float tr = cx+width/2f;
            float top = cy-height/2f;
            float bottom = cy+height/2f;

            float bl = tl-pad;
            float br = tr+pad;
            boolean left = "left".equals(position);

            if ("notch".equals(shape) && left) bl = dp(2);
            if ("notch".equals(shape) && "right".equals(position)) br = getWidth()-dp(2);

            RectF bg = new RectF(bl,top-dp(7),br,bottom+dp(7));

            Path bgPath = makePath(
                bg, shape, left,
                Math.min(radius, Math.min(bg.width()/2f,bg.height()/2f))
            );

            p.setColor(prefs.getInt("background",Color.BLACK));
            canvas.drawPath(bgPath,p);

            RectF track = new RectF(tl,top,tr,bottom);
            float r = width/2f;

            p.setColor(prefs.getInt("track",0xFF777777));
            canvas.drawRoundRect(track,r,r,p);

            float ratio = 0.68f;
            RectF fill = new RectF(tl,bottom-height*ratio,tr,bottom);

            canvas.save();
            canvas.clipRect(track);
            p.setColor(prefs.getInt("fill",Color.WHITE));
            canvas.drawRoundRect(fill,r,r,p);
            canvas.restore();
        }

        private int dp(float value) {
            return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
        }
    }
}
