
package com.mikita.volumebar;

import android.accessibilityservice.AccessibilityService;
import android.content.*;
import android.graphics.*;
import android.media.AudioManager;
import android.animation.ValueAnimator;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.*;
import android.widget.Toast;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

public class VolumeAccessibilityService extends AccessibilityService {

    private WindowManager wm;
    private VolumeView overlay;

    private final Handler handler = new Handler(Looper.getMainLooper());

    private Runnable hideRunnable;
    private static VolumeAccessibilityService instance;

    private boolean visible = false;
    private boolean exiting = false;

    private ValueAnimator progressAnimator;

    private float animatedRatio = 0f;
    private float targetRatio = 0f;

    private int animationGeneration = 0;

    // Répétition des boutons de volume
    private Runnable volumeRepeatRunnable;
    private int heldVolumeDirection = 0;
    private boolean volumeKeyHeld = false;

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();

        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        updateVolumeImmediately();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}

    @Override
    public void onInterrupt() {}

    @Override
    public boolean onKeyEvent(KeyEvent event) {

        int key = event.getKeyCode();

        if (key != KeyEvent.KEYCODE_VOLUME_UP &&
            key != KeyEvent.KEYCODE_VOLUME_DOWN) {
            return super.onKeyEvent(event);
        }

        int direction =
            key == KeyEvent.KEYCODE_VOLUME_UP ? 1 : -1;

        AudioManager audio =
            (AudioManager) getSystemService(AUDIO_SERVICE);

        if (event.getAction() == KeyEvent.ACTION_DOWN) {

            if (event.getRepeatCount() == 0) {

                heldVolumeDirection = direction;
                volumeKeyHeld = true;

                audio.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    direction > 0
                        ? AudioManager.ADJUST_RAISE
                        : AudioManager.ADJUST_LOWER,
                    0
                );

                showBar();
                animateProgress();

                if (volumeRepeatRunnable != null) {
                    handler.removeCallbacks(volumeRepeatRunnable);
                }

                volumeRepeatRunnable = new Runnable() {

                    @Override
                    public void run() {

                        if (!volumeKeyHeld ||
                            heldVolumeDirection != direction) {
                            return;
                        }

                        audio.adjustStreamVolume(
                            AudioManager.STREAM_MUSIC,
                            direction > 0
                                ? AudioManager.ADJUST_RAISE
                                : AudioManager.ADJUST_LOWER,
                            0
                        );

                        showBar();
                        animateProgress();

                        handler.postDelayed(this, 120);
                    }
                };

                handler.postDelayed(volumeRepeatRunnable, 350);
            }

            return true;
        }

        if (event.getAction() == KeyEvent.ACTION_UP) {

            volumeKeyHeld = false;
            heldVolumeDirection = 0;

            if (volumeRepeatRunnable != null) {
                handler.removeCallbacks(volumeRepeatRunnable);
                volumeRepeatRunnable = null;
            }

            return true;
        }

        return true;
    }

    private SharedPreferences prefs() {
        return getSharedPreferences("style", MODE_PRIVATE);
    }

    private float getVolumeRatio() {

        AudioManager audio =
            (AudioManager) getSystemService(AUDIO_SERVICE);

        int max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int current = audio.getStreamVolume(AudioManager.STREAM_MUSIC);

        if (max <= 0) return 0f;

        return Math.max(0f, Math.min(1f, (float) current / max));
    }

    private void updateVolumeImmediately() {
        animatedRatio = getVolumeRatio();
        targetRatio = animatedRatio;
    }

    private void animateProgress() {

        targetRatio = getVolumeRatio();

        if (progressAnimator != null) {
            progressAnimator.cancel();
            progressAnimator = null;
        }

        if (overlay == null) return;

        String style = prefs().getString("progressAnimation", "smooth");

        if ("none".equals(style)) {
            animatedRatio = targetRatio;
            overlay.invalidate();
            return;
        }

        int duration = prefs().getInt("progressDuration", 220);

        progressAnimator = ValueAnimator.ofFloat(
            animatedRatio,
            targetRatio
        );

        progressAnimator.setDuration(duration);

        if ("spring".equals(style)) {
            progressAnimator.setInterpolator(
                new OvershootInterpolator(0.65f)
            );
        } else if ("linear".equals(style)) {
            progressAnimator.setInterpolator(
                new LinearInterpolator()
            );
        } else {
            progressAnimator.setInterpolator(
                new DecelerateInterpolator(2f)
            );
        }

        progressAnimator.addUpdateListener(animation -> {

            animatedRatio = (float) animation.getAnimatedValue();

            if (overlay != null) {
                overlay.invalidate();
            }
        });

        progressAnimator.start();
    }

    private void showBar() {

        if (wm == null) return;

        if (hideRunnable != null) {
            handler.removeCallbacks(hideRunnable);
            hideRunnable = null;
        }

        animationGeneration++;

        if (overlay == null) {

            updateVolumeImmediately();

            overlay = new VolumeView(this);

            WindowManager.LayoutParams params =
                new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                );

            params.gravity = Gravity.TOP | Gravity.START;

            try {
                wm.addView(overlay, params);
            } catch (Exception e) {
                overlay = null;
                return;
            }

            visible = false;
            exiting = false;
        }

        overlay.invalidate();

        if (exiting) {

            overlay.animate().cancel();

            exiting = false;
            visible = true;

            overlay.setVisibility(View.VISIBLE);
            overlay.setAlpha(1f);
            overlay.setTranslationX(0f);
            overlay.setTranslationY(0f);

        } else if (!visible) {

            visible = true;
            exiting = false;

            overlay.animate().cancel();

            overlay.setVisibility(View.VISIBLE);
            overlay.setAlpha(0f);
            overlay.setTranslationX(0f);
            overlay.setTranslationY(0f);

            String animation = prefs().getString("animation", "fade");

            int duration = prefs().getInt("duration", 180);

            float movement = dp(22);

            if ("slide".equals(animation) ||
                "both".equals(animation)) {
                overlay.setTranslationX(movement);
            }

            if ("fade".equals(animation) ||
                "both".equals(animation)) {

                overlay.animate()
                    .alpha(1f)
                    .translationX(0f)
                    .setDuration(duration)
                    .start();

            } else if ("slide".equals(animation)) {

                overlay.setAlpha(1f);

                overlay.animate()
                    .translationX(0f)
                    .setDuration(duration)
                    .start();

            } else {

                overlay.setAlpha(1f);
                overlay.setTranslationX(0f);
            }

        } else {

            overlay.animate().cancel();

            overlay.setVisibility(View.VISIBLE);
            overlay.setAlpha(1f);
            overlay.setTranslationX(0f);
            overlay.setTranslationY(0f);
        }

        hideRunnable = this::hideBar;

        handler.postDelayed(
            hideRunnable,
            prefs().getInt("hideDelay", 1600)
        );
    }

    private void hideBar() {

        if (overlay == null || !visible) return;

        final View exitingView = overlay;

        visible = false;
        exiting = true;

        final int currentGeneration = ++animationGeneration;

        String exit = prefs().getString("exitAnimation", "fade");

        int duration = prefs().getInt("exitDuration", 180);

        exitingView.animate().cancel();

        float movement = dp(22);

        if ("none".equals(exit) || duration <= 0) {
            removeOverlay(exitingView, currentGeneration);
            return;
        }

        ViewPropertyAnimator animator =
            exitingView.animate().setDuration(duration);

        if ("fade".equals(exit)) {

            animator.alpha(0f);

        } else if ("slide".equals(exit)) {

            String position = prefs().getString("position", "right");

            if ("left".equals(position)) {
                animator.translationX(-movement);
            } else {
                animator.translationX(movement);
            }

        } else if ("both".equals(exit)) {

            String position = prefs().getString("position", "right");

            if ("left".equals(position)) {
                animator.translationX(-movement);
            } else {
                animator.translationX(movement);
            }

            animator.alpha(0f);

        } else {
            animator.alpha(0f);
        }

        animator.setListener(new AnimatorListenerAdapter() {

            private boolean cancelled = false;

            @Override
            public void onAnimationCancel(Animator animation) {
                cancelled = true;
            }

            @Override
            public void onAnimationEnd(Animator animation) {

                if (cancelled) return;

                if (currentGeneration != animationGeneration) return;

                if (overlay != exitingView) return;

                removeOverlay(exitingView, currentGeneration);
            }
        });

        animator.start();
    }

    private void removeOverlay(View target, int generation) {

        if (generation != animationGeneration) return;

        if (overlay != target) return;

        target.setVisibility(View.INVISIBLE);

        target.animate().cancel();

        if (progressAnimator != null) {
            progressAnimator.cancel();
            progressAnimator = null;
        }

        try {
            if (wm != null) {
                wm.removeViewImmediate(target);
            }
        } catch (Exception ignored) {}

        overlay = null;
        visible = false;
        exiting = false;
    }

    public static void preview(Context context) {

        if (instance != null) {
            instance.showBar();
        } else {
            Toast.makeText(
                context,
                "Active d'abord le service d'accessibilité.",
                Toast.LENGTH_LONG
            ).show();
        }
    }

    public static void refresh() {

        if (instance != null && instance.overlay != null) {
            instance.overlay.invalidate();
        }
    }

    public static boolean isEnabled(Context context) {

        String id = context.getPackageName() + "/" +
            VolumeAccessibilityService.class.getName();

        String enabled = Settings.Secure.getString(
            context.getContentResolver(),
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        );

        return enabled != null &&
            enabled.toLowerCase().contains(id.toLowerCase());
    }

    private int dp(float value) {

        return (int) (
            value * getResources().getDisplayMetrics().density + 0.5f
        );
    }

    private class VolumeView extends View {

        private final Paint paint =
            new Paint(Paint.ANTI_ALIAS_FLAG);

        VolumeView(Context context) {
            super(context);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        private Path createBackground(
            RectF rect,
            String shape,
            boolean leftNotch,
            float radius
        ) {

            Path path = new Path();

            if ("square".equals(shape)) {

                path.addRect(rect, Path.Direction.CW);

            } else if ("notch".equals(shape)) {

                float[] radii = leftNotch
                    ? new float[]{
                        0, 0,
                        radius, radius,
                        radius, radius,
                        0, 0
                    }
                    : new float[]{
                        radius, radius,
                        0, 0,
                        0, 0,
                        radius, radius
                    };

                path.addRoundRect(rect, radii, Path.Direction.CW);

            } else {

                float r = "round".equals(shape)
                    ? Math.min(radius, rect.width() / 2f)
                    : rect.width() / 2f;

                path.addRoundRect(
                    rect,
                    r,
                    r,
                    Path.Direction.CW
                );
            }

            return path;
        }

        @Override
        protected void onDraw(Canvas canvas) {

            super.onDraw(canvas);

            SharedPreferences s = prefs();

            float d = getResources().getDisplayMetrics().density;

            String shape = s.getString("shape", "pill");
            String position = s.getString("position", "right");

            int background = s.getInt("background", Color.BLACK);
            int trackColor = s.getInt("track", 0xFF777777);
            int fillColor = s.getInt("fill", Color.WHITE);

            float height = s.getInt("length", 230) * d;
            float trackWidth = s.getInt("thickness", 8) * d;

            float padding = s.getInt("backgroundPadding", 10) * d;

            float radius = s.getInt("radius", 18) * d;

            float margin = s.getInt("margin", 28) * d;
            float offsetX = s.getInt("offsetX", 0) * d;
            float offsetY = s.getInt("offsetY", 0) * d;

            float centerX;

            if ("left".equals(position)) {
                centerX = margin + trackWidth / 2f;
            } else if ("center".equals(position)) {
                centerX = getWidth() / 2f;
            } else {
                centerX = getWidth() - margin - trackWidth / 2f;
            }

            centerX += offsetX;

            float centerY = getHeight() / 2f + offsetY;

            float trackLeft = centerX - trackWidth / 2f;
            float trackRight = centerX + trackWidth / 2f;

            float bgLeft = trackLeft - padding;
            float bgRight = trackRight + padding;

            boolean leftNotch = "left".equals(position);

            if ("notch".equals(shape) && leftNotch) {
                bgLeft = offsetX;
            } else if ("notch".equals(shape) && "right".equals(position)) {
                bgRight = getWidth() + offsetX;
            }

            float top = centerY - height / 2f;
            float bottom = centerY + height / 2f;

            RectF bgRect = new RectF(
                bgLeft,
                top - dp(7),
                bgRight,
                bottom + dp(7)
            );

            float bgRadius = Math.min(
                radius,
                Math.min(bgRect.width() / 2f, bgRect.height() / 2f)
            );

            Path bgPath = createBackground(
                bgRect,
                shape,
                leftNotch,
                bgRadius
            );

            // FOND
            paint.setColor(background);
            canvas.drawPath(bgPath, paint);

            // PISTE
            RectF trackRect = new RectF(
                trackLeft,
                top,
                trackRight,
                bottom
            );

            float trackRadius = trackWidth / 2f;

            paint.setColor(trackColor);

            canvas.drawRoundRect(
                trackRect,
                trackRadius,
                trackRadius,
                paint
            );

            // PROGRESSION
            float ratio = Math.max(
                0f,
                Math.min(1f, animatedRatio)
            );

            float fillTop = bottom - height * ratio;

            RectF fillRect = new RectF(
                trackLeft,
                fillTop,
                trackRight,
                bottom
            );

            canvas.save();
            canvas.clipRect(trackRect);

            paint.setColor(fillColor);

            canvas.drawRoundRect(
                fillRect,
                trackRadius,
                trackRadius,
                paint
            );

            canvas.restore();
        }
    }

    @Override
    public void onDestroy() {

        volumeKeyHeld = false;

        if (volumeRepeatRunnable != null) {
            handler.removeCallbacks(volumeRepeatRunnable);
            volumeRepeatRunnable = null;
        }

        if (hideRunnable != null) {
            handler.removeCallbacks(hideRunnable);
        }

        if (progressAnimator != null) {
            progressAnimator.cancel();
            progressAnimator = null;
        }

        if (overlay != null) {
            try {
                wm.removeViewImmediate(overlay);
            } catch (Exception ignored) {}

            overlay = null;
        }

        visible = false;
        exiting = false;
        instance = null;

        super.onDestroy();
    }
}
